LIA_outlines_UTM33N.shp

Shapefile containing glacier outlines of Jostedalsbreen (southern Norway) at Little Ice Age (LIA) maximum extent based on ice-marginal moraines and other landforms and land cover.
The data set and the uncertainties associated with the reconstruction are described in detail in Carrivck et al. (submitted).

The dataset is divided into glaciers using the divides and the local IDs from the 1999-2006 inventory of Norwegian glaciers (Andreassen et al. 2012: Inventory of Norwegian glaciers. NVE Rapport 38, Norges Vassdrags- og energidirektorat, 236 pp).

----------------------------------------
When using the data cite:
Carrivick, J.L., Andreassen, L.M., Nesje, A., Yde, J.C., submitted. Quaternary Science Reviews. 